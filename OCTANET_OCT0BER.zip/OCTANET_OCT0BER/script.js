// Initially hide all sections except the navigation bar
document.addEventListener('DOMContentLoaded', function () {
    hideAllSections();
    document.getElementById('home').style.display = 'block';  // Show home section by default
});

// Function to hide all sections
function hideAllSections() {
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });
}

// Function to show the selected section and hide others
function showSection(sectionId) {
    hideAllSections();  // Hide all sections first
    document.getElementById(sectionId).style.display = 'block';  // Show the selected section
}

// Form handling (for registration form)
document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting automatically

    // Get the form values
    const name = document.getElementById('name').value;
    const dob = document.getElementById('dob').value;
    const email = document.getElementById('email').value;
    const location = document.getElementById('location').value;
    const mobile = document.getElementById('mobile').value;
    const domain = document.getElementById('domain').value;

    // Validate the required fields
    if (name && dob && email && domain) {
        alert("Registration Successful! Thank you for registering, " + name);
        // Additional code to handle form data submission (AJAX, fetch, etc.) can go here
    } else {
        alert("Please fill in all the required fields.");
    }
});
